import React,{Component} from "react";
import { useDispatch } from "react-redux";
import { setObject } from "../redux/actions";
import { connect } from "react-redux";
import { obj } from "./globalIP";
import { SpinnerGap } from "phosphor-react";
import { DivComponent } from "./divider";
import EncryptData from "../encryption";

let temp = true;

//------------class implementation of the same thing
class NetworkObject extends Component{
    constructor(props) {
        super(props)
        this.state = {
            data: [],
            loading: false,
            error: 'Network error',
            errror_occured: false,
            doneFetching:false,
            url: `http://${obj.serverIP}:1000/temper/get-list`,
            defaultUrl: `http://${obj.serverIP}:4000`,
            isComponentMounted:false,
            response: null,
            setObject: setObject,
            dispatch:useDispatch,
            adminID: "XFMRBEJZCN",
            storageObj : {
                storeReady: false,
                 packagesList: [ ],
                defaultVoucherCode: '2345',
                availableRunningCodes: [ ],
                admin: { },
                clientTimeFrames: [],
                graphData: [],
                merchantCode: '',
                phoneNumber:''
            }
        }
        
        this.newObj={}

        this.hasErrorOccured = this.hasErrorOccured.bind(this);
     //   this.start_data_seeking = this.start_data_seeking(this);
    }

    componentDidMount() {
        //   this.getStore();
        //this.start_server_seeking();

        this.setState({ isComponentMounted: true });
        this.setState({ errror_occured: temp });
        this.setState({ loading: temp ? true : false });
        
    }

    setAdminID = (id) => {
        console.log("id>>>" + id);
        
        if (this.state.isComponentMounted) this.setState({ adminID: id });
        this.state.adminID = id;
    }

    hasErrorOccured=()=>{
        return this.state.errror_occured ? true : false;
    }

    getNewVoucher =async (expiry) => {
        const obj = {expiryTime:expiry };

        this.setState({ loading: true });

        return await fetch(`${this.state.defaultUrl}/session/generate-voucher`,
            {
                method: 'POST',
                body: JSON.stringify(obj),
                headers: { 'Content-Type': 'application/json' }
            })
            .then((res)=>res.json())
            .then((result) => {
               // alert(Object.keys(result));
                if (result.code!==undefined) return result;
                else {
                    console.log('Failed to generate code');
                    return false;
                }
            })
            .catch(err => { throw new Error('Error occured:' + err) })
    }

    sendPostRequest = async (data, route) => {
        data = EncryptData(data);

        return await fetch(`${this.state.defaultUrl}${route} `,
            {
                body: JSON.stringify({ data: data }) ,
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            })
            .then((result)=>result.json())
            .then((result) => {
                if (result.status !== 200) {
               //     alert('Server or network error');
                    console.log('Request Failure...'+result.message) // throw new Error('Failed to post Request...');
                    return false;
                }

                    console.log('Post request succefully submitted');
                return {data:result}
                    })

    }
    
    sendVoucher = (code) => {
        code = EncryptData(code);
        const ip = '192.168.43.120';

        this.setState({ loading: true });
        this.state.loading = true;

        fetch(`${this.defaultUrl}/client/authenticate-client?code=${code}&ip=${ip}`,
            {
                method: 'GET',
                headers: {
                    'Authorization':`Bearer ${code}`,
                },  
            })
            
            .then(resp => {           //fetching the data
            this.setState({ response: resp.status === 200 ? this.setState(resp.json()) : null })
            if (this.state.response === null) {
                this.setState({ error: resp.message });
                this.state.error = resp.message;
                this.state.errror_occured = true;
                this.state.laoding = false;

                console.log(resp.message);
             //   this.setState({ loading: false });
              //  this.setState({ errror_occured: true });
            }
        })
            .then(() => {       //storing the data in the store
                if (this.state.errror_occured) return false;

                console.log(JSON.stringify(this.state.response, null, 2));
                return true;
           })
            .catch((err) => {
                this.state.error = err;
                this.setState({ error: err })
            })
    }

    sendLogin = ({ user, password }) => {  //from authPage.js
        let obj = {
            method: 'POST',
            headers:{'Content-Type':'application/json'},
            body: {
                username: user,
                password: password
            }
        }

      //  obj = EncryptData(obj);

        if (this.state.isComponentMounted)  this.setState({ loading: true });

        fetch(`${this.defaultUrl}/client/authenticate-client`,
            {
                body: JSON.stringify(obj),
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            },
            )

            .then(resp => {           //fetching the data
                this.setState({ response: resp.status === 200 ? this.setState(resp.json()) : null })
                if (this.state.response === null) {
                    this.setState({ error: resp.message });
               //     this.setState({ errror_occured: true })
                    this.state.errror_occured = true;

                    console.log(resp.message);
                    this.setState({ loading: false });
                    this.state.laoding = false;
                }
            })
            .then(() => {       //storing the data in the store
                if (this.state.errror_occured) return false;
                return true;
                //   return JSON.parse(JSON.stringify(this.state.response, null, 2));
            })
            .catch((err) => {
                this.setState({ error: err });
                console.log(err);
            })
    }

    start_server_seeking = async () => {
  

        try {
            if (this.state.errror_occured) return;

            return await fetch(`http://localhost:4000/admin/ping`)
                .then((result) => {
                     return result.json()
                }    )
                .then((result) => {
                    if ( result.message === undefined) {
                        //   alert('Network error detected');
                        temp = true;
                        console.log('cannot connect to the server'); 
                        this.state.errror_occured = true;
                        this.setState({ errror_occured: true });
                        return false;
                    }
                    else {
                     
                        temp = false;
                        this.state.loading = true;
                        return true;
                    }
                
                });
        }
        catch (e) {
            temp = true;
            this.state.errror_occured = true;
            console.log('cannot connect to the server'); 
            setInterval(() => { this.start_server_seeking() }, 10000);
     
            console.error(e);
        }
    }

    getStoreData =async (route,property) => {
        console.log('connecting to: ' + this.state.defaultUrl + route);

        //avoiding repeated calls due to state changes
        if (this.state.errror_occured || this.state.response !== null || this.state.doneFetching) {
            return;
        }

      await  fetch(
            'http://localhost:4000'+route)
            .then(resp => resp.json())
            .then((resp) => {
                console.log(`Result for ${this.state.defaultUrl + route}`, resp.data);
                
                if (resp.data !== undefined) {
                    this.state.storageObj[property] = resp.data.data;
                    //this.setState({ storageObj.property: resp.data });
                  //last call??
                    if (property === 'phoneNumber') this.saveDataToRedux();
                }
                else {
                    if (resp.message !== undefined || resp.data!==undefined) console.log(resp.message);
                    else console.log('Network error...');
                    this.setState({ errror_occured: true });
                    this.state.errror_occured = true;
                }


                setTimeout(() => {
                    if (this.state.response !== null) {
                        this.setState({ loading: true });
                        this.state.loading = true;
                        this.state.error = '';
                        this.setState({ error: '' })
                    }
                }, 8000);
            })

            .catch((err) => console.error(err));
    }

    saveDataToRedux =async () => {
        const Saver = ()=> {
            console.log('Stored data in redux');
        }
        
        const startMonitoring = () => {
            //polling the server after every hour in intervals for time updates
            console.log('monitoring next time updated started....');

            setInterval(() => {
                this.sendPostRequest({}, '/get-all-vouchers-in-memory')
            }, (60 * 60000));

        }

        Saver();
        startMonitoring();
}

    isNetworkError=() => { return this.state.errror_occured}
  
    /*
    getStore = () => {
        console.log('connecting to: ' + this.state.defaultUrl + '/admin/get-redux');
        
        //avoiding repeated calls due to state changes
        if (this.state.errror_occured || this.state.response !== null || this.state.doneFetching) {
            return;
        }

        fetch(
            'http://localhost:4000/admin/get-redux',
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminID: this.state.adminID })
            })
            
            .then(resp => resp.json())
            .then((resp) => {
                console.log(resp.data);
                if (resp.data !== undefined) this.setState({ response: resp.data });
                else {
                    if (resp.message !== undefined) console.log(resp.message);
                    else console.log('Network error...');
                    this.setState({ errror_occured: true });
                }

                this.setState({ error: '' });
                this.setState({ doneFetching: true });

                setTimeout(() => {
                    if (this.state.response !== null) {
                        this.setState({ loading: true });
                        this.setState({ error: '' })
                    }
                }, 8000);
            })

            .then(() => {
                this.state.setObject(this.state.response);
                console.log('Stored data in redux');
            })
            .then(() => {
                //polling the server after every hour in intervals for time updates
                console.log('monitoring next time updated started....');
        
                setInterval(() => {
                    this.sendPostRequest({}, '/get-all-vouchers-in-memory')
                }, (60 * 60000));
    })
            .catch((err) => console.error(err));
    }
*/

    gatherObtainedData = () => {
        return tempObj;
    }

//-----ignoring this method for now
    render() { 
 

        if (this.state.errror_occured) {
            setInterval(() => {
                this.start_server_seeking();
            }, 10000);
        }

        this.start_server_seeking().then((result) => {
            return;
       
        });
        //calling each method to fetch the data independenlty  
        
        return (
            <DivComponent className='lg:ml-[80%] !lg:mt-[10%]'>
                {this.state.loading === true ? <SpinnerGap color="white" className="animate-spin" size={20.0} /> :
                    <label className=" hidden">{this.state.error}</label>
                }   
            </DivComponent>    
                )
    }


}


const networkObject = new NetworkObject();
networkObject.start_server_seeking();  //checking if server is available


let tempObj ={
    storeReady:false,
    packagesList: [ ],
    defaultVoucherCode: 'tr467d',
    availableRunningCodes: [],
    admin: {},
    clientTimeFrames: ['1-HR','6-HRS','12-HRS','24-HRS','48-HRS(2Days)','72-HRS(3Days)','1-week','1-month'],
    graphData: [],
    merchantCode: '',
}

const getAllData = async () => {

    try{
   const getData = async (route,property) => {
    console.log('connecting to: http://localhost:4000'+ route);

   return await fetch(
            'http://localhost:4000' + route)
            .then(resp => resp.json())
            .then((resp) => {
                console.log(`Result for ${'http://localhost:4000' + route}`, resp.data);

                if (resp.data !== undefined) {
                    if (property === 'availableRunningCodes') tempObj.availableRunningCodes = resp.data;
                    if (property === 'merchantCode') tempObj.merchantCode = resp.data.data;
                    if (property === 'phoneNumber') tempObj.phoneNumber = resp.data.data.data;
                    if(property==='packagesList')   tempObj.packagesList = resp.data.data;
                    if (property === 'admin')  tempObj.admin = resp.data.data.data;
                    return true;
                }
                else {
                    if (resp.message !== undefined || resp.data !== undefined) console.log(resp.message);
                    else console.log('Network error...');
                }

            })
            .catch((err) => console.error(err));
        }

        if (networkObject.state.adminID === undefined || networkObject.state.errror_occured) return;
      
        getData(`/admin/get-packages?id=${EncryptData(networkObject.state.adminID)}`, 'packagesList');
        getData(`/admin/get-admin-by-id?id=${EncryptData(networkObject.state.adminID) }`, 'admin');
  //      getData(`/admin/get-all-clients?id=${EncryptData(networkObject.state.adminID)}`, 'availableRunningCodes');
        getData(`/admin/get-merchant-code?id=${EncryptData(networkObject.state.adminID) }`, 'merchantCode');
        getData(`/admin/get-phone-numbers?id=${EncryptData(networkObject.state.adminID) }`, 'phoneNumber');
        getData(`/session/get-all-vouchers-in-memory?id=${networkObject.state.adminID}`, 'availableRunningCodes');
        

    //    networkObject.sendPostRequest({ username: 'delos', password: '1234' }, '/admin/login-admin');
    }
    catch (e) {
        console.log(e);
}      
}


const stateToProps = (state) => { return { data: state.response } };

const mapDispatchToPropsX =async (dispatch) => {
   await getAllData();
    setTimeout(() => { dispatch(setObject(tempObj)); }, 800);    

    return { setObject: (data) => dispatch(setObject(tempObj)) }
}

export { networkObject };

export default connect(stateToProps, mapDispatchToPropsX)(NetworkObject);
